package javabc;


public class FilterInputStream extends java.io.InputStream {

	protected java.io.InputStream in;

	protected FilterInputStream(java.io.InputStream underlying) {
	}

	public int read() {
	}

	public int read(byte[] b) {
	}

	public int read(byte[] b, int offset, int length) {
	}

	public long skip(long n) {
	}

	public int available() {
	}

	public void close() {
	}

	public void mark(int readlimit) {
	}

	public void reset() {
	}

	public boolean markSupported() {
	}
}
