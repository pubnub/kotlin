package javabc;


public class FilterOutputStream extends java.io.OutputStream {

	protected java.io.OutputStream out;

	protected FilterOutputStream(java.io.OutputStream underlying) {
	}

	public void write(int b) {
	}

	public void write(byte[] b) {
	}

	public void write(byte[] b, int offset, int length) {
	}

	public void flush() {
	}

	public void close() {
	}
}
