package org.bouncycastle.asn1.x500.style;


public class IETFUtils {

	public IETFUtils() {
	}

	public static org.bouncycastle.asn1.x500.RDN[] rDNsFromString(String name, org.bouncycastle.asn1.x500.X500NameStyle x500Style) {
	}

	public static org.bouncycastle.asn1.ASN1ObjectIdentifier decodeAttrName(String name, java.util.Hashtable lookUp) {
	}

	public static org.bouncycastle.asn1.ASN1Encodable valueFromHexString(String str, int off) {
	}

	public static void appendTypeAndValue(StringBuffer buf, org.bouncycastle.asn1.x500.AttributeTypeAndValue typeAndValue, java.util.Hashtable oidSymbols) {
	}

	public static String valueToString(org.bouncycastle.asn1.ASN1Encodable value) {
	}

	public static String canonicalize(String s) {
	}

	public static String stripInternalSpaces(String str) {
	}
}
