/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class PBES2Parameters extends org.bouncycastle.asn1.ASN1Object {

	public PBES2Parameters(org.bouncycastle.asn1.ASN1Sequence obj) {
	}

	public static PBES2Parameters getInstance(Object obj) {
	}

	public KeyDerivationFunc getKeyDerivationFunc() {
	}

	public EncryptionScheme getEncryptionScheme() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
