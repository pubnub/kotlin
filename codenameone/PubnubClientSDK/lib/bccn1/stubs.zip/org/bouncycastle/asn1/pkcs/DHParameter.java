/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class DHParameter extends org.bouncycastle.asn1.ASN1Object {

	public DHParameter(javabc.BigInteger p, javabc.BigInteger g, int l) {
	}

	public static DHParameter getInstance(Object obj) {
	}

	public javabc.BigInteger getP() {
	}

	public javabc.BigInteger getG() {
	}

	public javabc.BigInteger getL() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
