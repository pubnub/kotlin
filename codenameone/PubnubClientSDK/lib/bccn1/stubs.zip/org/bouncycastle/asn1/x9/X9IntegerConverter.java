/**
 * 
 * Support classes useful for encoding and supporting X9.62 elliptic curve.
 */
package org.bouncycastle.asn1.x9;


public class X9IntegerConverter {

	public X9IntegerConverter() {
	}

	public int getByteLength(org.bouncycastle.math.ec.ECCurve c) {
	}

	public int getByteLength(org.bouncycastle.math.ec.ECFieldElement fe) {
	}

	public byte[] integerToBytes(javabc.BigInteger s, int qLength) {
	}
}
