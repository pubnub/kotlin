/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class PKCS12PBEParams extends org.bouncycastle.asn1.ASN1Object {

	public PKCS12PBEParams(byte[] salt, int iterations) {
	}

	public static PKCS12PBEParams getInstance(Object obj) {
	}

	public javabc.BigInteger getIterations() {
	}

	public byte[] getIV() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
