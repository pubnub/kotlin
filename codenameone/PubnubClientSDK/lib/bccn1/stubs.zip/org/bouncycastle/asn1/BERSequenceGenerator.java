/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class BERSequenceGenerator extends BERGenerator {

	public BERSequenceGenerator(java.io.OutputStream out) {
	}

	public BERSequenceGenerator(java.io.OutputStream out, int tagNo, boolean isExplicit) {
	}

	public void addObject(ASN1Encodable object) {
	}

	public void close() {
	}
}
