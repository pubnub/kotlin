/**
 * 
 * Objects and OID for the support of ISO OIW.
 */
package org.bouncycastle.asn1.oiw;


public class ElGamalParameter extends org.bouncycastle.asn1.ASN1Object {

	public ElGamalParameter(javabc.BigInteger p, javabc.BigInteger g) {
	}

	public ElGamalParameter(org.bouncycastle.asn1.ASN1Sequence seq) {
	}

	public javabc.BigInteger getP() {
	}

	public javabc.BigInteger getG() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
