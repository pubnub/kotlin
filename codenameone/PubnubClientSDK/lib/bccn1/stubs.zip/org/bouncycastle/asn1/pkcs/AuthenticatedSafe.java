/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class AuthenticatedSafe extends org.bouncycastle.asn1.ASN1Object {

	public AuthenticatedSafe(ContentInfo[] info) {
	}

	public static AuthenticatedSafe getInstance(Object o) {
	}

	public ContentInfo[] getContentInfo() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
