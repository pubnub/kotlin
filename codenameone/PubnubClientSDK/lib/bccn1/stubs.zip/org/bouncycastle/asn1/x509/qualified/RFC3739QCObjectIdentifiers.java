/**
 * 
 * Support classes useful for encoding and processing messages based around RFC3739
 */
package org.bouncycastle.asn1.x509.qualified;


public class RFC3739QCObjectIdentifiers {

	public RFC3739QCObjectIdentifiers() {
	}
}
