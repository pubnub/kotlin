/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class RC2CBCParameter extends org.bouncycastle.asn1.ASN1Object {

	public RC2CBCParameter(byte[] iv) {
	}

	public RC2CBCParameter(int parameterVersion, byte[] iv) {
	}

	public static RC2CBCParameter getInstance(Object o) {
	}

	public javabc.BigInteger getRC2ParameterVersion() {
	}

	public byte[] getIV() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
