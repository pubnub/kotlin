/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class ASN1Enumerated extends DEREnumerated {

	public ASN1Enumerated(javabc.BigInteger value) {
	}

	public ASN1Enumerated(int value) {
	}
}
