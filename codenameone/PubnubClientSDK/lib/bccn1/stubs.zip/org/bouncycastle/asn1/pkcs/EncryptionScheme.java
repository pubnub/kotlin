/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class EncryptionScheme extends org.bouncycastle.asn1.x509.AlgorithmIdentifier {

	public EncryptionScheme(org.bouncycastle.asn1.ASN1ObjectIdentifier objectId, org.bouncycastle.asn1.ASN1Encodable parameters) {
	}

	public static final org.bouncycastle.asn1.x509.AlgorithmIdentifier getInstance(Object obj) {
	}

	public org.bouncycastle.asn1.ASN1Primitive getObject() {
	}

	public org.bouncycastle.asn1.ASN1Primitive getASN1Primitive() {
	}
}
