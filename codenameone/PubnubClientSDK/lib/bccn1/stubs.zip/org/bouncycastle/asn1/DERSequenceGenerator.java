/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class DERSequenceGenerator extends DERGenerator {

	public DERSequenceGenerator(java.io.OutputStream out) {
	}

	public DERSequenceGenerator(java.io.OutputStream out, int tagNo, boolean isExplicit) {
	}

	public void addObject(ASN1Encodable object) {
	}

	public java.io.OutputStream getRawOutputStream() {
	}

	public void close() {
	}
}
