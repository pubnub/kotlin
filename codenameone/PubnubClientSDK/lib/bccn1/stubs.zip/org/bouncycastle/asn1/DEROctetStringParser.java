/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class DEROctetStringParser implements ASN1OctetStringParser {

	public java.io.InputStream getOctetStream() {
	}

	public ASN1Primitive getLoadedObject() {
	}

	public ASN1Primitive toASN1Primitive() {
	}
}
