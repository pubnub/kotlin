/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class DERGeneralString extends ASN1Primitive implements ASN1String {

	public DERGeneralString(String string) {
	}

	public static DERGeneralString getInstance(Object obj) {
	}

	public static DERGeneralString getInstance(ASN1TaggedObject obj, boolean explicit) {
	}

	public String getString() {
	}

	public String toString() {
	}

	public byte[] getOctets() {
	}

	public int hashCode() {
	}
}
