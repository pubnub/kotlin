/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class CertBag extends org.bouncycastle.asn1.ASN1Object {

	public CertBag(org.bouncycastle.asn1.ASN1ObjectIdentifier certId, org.bouncycastle.asn1.ASN1Encodable certValue) {
	}

	public static CertBag getInstance(Object o) {
	}

	public org.bouncycastle.asn1.ASN1ObjectIdentifier getCertId() {
	}

	public org.bouncycastle.asn1.ASN1Encodable getCertValue() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
