/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class ASN1StreamParser {

	public ASN1StreamParser(java.io.InputStream in) {
	}

	public ASN1StreamParser(java.io.InputStream in, int limit) {
	}

	public ASN1StreamParser(byte[] encoding) {
	}

	public ASN1Encodable readObject() {
	}
}
