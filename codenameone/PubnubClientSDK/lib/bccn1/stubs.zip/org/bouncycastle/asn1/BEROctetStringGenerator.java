/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class BEROctetStringGenerator extends BERGenerator {

	public BEROctetStringGenerator(java.io.OutputStream out) {
	}

	public BEROctetStringGenerator(java.io.OutputStream out, int tagNo, boolean isExplicit) {
	}

	public java.io.OutputStream getOctetOutputStream() {
	}

	public java.io.OutputStream getOctetOutputStream(byte[] buf) {
	}
}
