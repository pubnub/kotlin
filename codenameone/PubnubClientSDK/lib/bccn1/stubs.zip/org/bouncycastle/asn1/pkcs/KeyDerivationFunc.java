/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class KeyDerivationFunc extends org.bouncycastle.asn1.x509.AlgorithmIdentifier {

	public KeyDerivationFunc(org.bouncycastle.asn1.ASN1ObjectIdentifier id, org.bouncycastle.asn1.ASN1Encodable params) {
	}
}
