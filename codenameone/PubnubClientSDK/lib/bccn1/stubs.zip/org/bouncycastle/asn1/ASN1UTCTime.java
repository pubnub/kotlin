/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class ASN1UTCTime extends DERUTCTime {

	public ASN1UTCTime(java.util.Date date) {
	}

	public ASN1UTCTime(String time) {
	}
}
