/**
 * 
 * Support classes useful for encoding and supporting the various RSA PKCS documents.
 */
package org.bouncycastle.asn1.pkcs;


public class PBEParameter extends org.bouncycastle.asn1.ASN1Object {

	public PBEParameter(byte[] salt, int iterations) {
	}

	public static PBEParameter getInstance(Object obj) {
	}

	public javabc.BigInteger getIterationCount() {
	}

	public byte[] getSalt() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
