/**
 * 
 * A library for parsing and writing ASN.1 objects. Support is provided for DER and BER encoding.
 */
package org.bouncycastle.asn1;


public class BERSetParser implements ASN1SetParser {

	public ASN1Encodable readObject() {
	}

	public ASN1Primitive getLoadedObject() {
	}

	public ASN1Primitive toASN1Primitive() {
	}
}
