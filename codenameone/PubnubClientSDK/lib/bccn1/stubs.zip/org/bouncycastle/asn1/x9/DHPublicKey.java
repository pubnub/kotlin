/**
 * 
 * Support classes useful for encoding and supporting X9.62 elliptic curve.
 */
package org.bouncycastle.asn1.x9;


public class DHPublicKey extends org.bouncycastle.asn1.ASN1Object {

	public DHPublicKey(org.bouncycastle.asn1.ASN1Integer y) {
	}

	public static DHPublicKey getInstance(org.bouncycastle.asn1.ASN1TaggedObject obj, boolean explicit) {
	}

	public static DHPublicKey getInstance(Object obj) {
	}

	public org.bouncycastle.asn1.ASN1Integer getY() {
	}

	public org.bouncycastle.asn1.ASN1Primitive toASN1Primitive() {
	}
}
