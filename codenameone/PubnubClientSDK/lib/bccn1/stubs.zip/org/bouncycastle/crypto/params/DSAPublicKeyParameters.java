/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DSAPublicKeyParameters extends DSAKeyParameters {

	public DSAPublicKeyParameters(javabc.BigInteger y, DSAParameters params) {
	}

	public javabc.BigInteger getY() {
	}
}
