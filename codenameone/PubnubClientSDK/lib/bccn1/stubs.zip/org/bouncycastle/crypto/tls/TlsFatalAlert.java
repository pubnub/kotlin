/**
 * 
 * A lightweight TLS API.
 */
package org.bouncycastle.crypto.tls;


public class TlsFatalAlert extends java.io.IOException {

	public TlsFatalAlert(short alertDescription) {
	}

	public short getAlertDescription() {
	}
}
