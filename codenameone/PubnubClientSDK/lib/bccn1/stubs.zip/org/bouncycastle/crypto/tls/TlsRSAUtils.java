/**
 * 
 * A lightweight TLS API.
 */
package org.bouncycastle.crypto.tls;


public class TlsRSAUtils {

	public TlsRSAUtils() {
	}

	public static byte[] generateEncryptedPreMasterSecret(TlsClientContext context, org.bouncycastle.crypto.params.RSAKeyParameters rsaServerPublicKey, java.io.OutputStream os) {
	}
}
