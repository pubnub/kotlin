/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class ECPrivateKeyParameters extends ECKeyParameters {

	public ECPrivateKeyParameters(javabc.BigInteger d, ECDomainParameters params) {
	}

	public javabc.BigInteger getD() {
	}
}
