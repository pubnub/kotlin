/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DSAPrivateKeyParameters extends DSAKeyParameters {

	public DSAPrivateKeyParameters(javabc.BigInteger x, DSAParameters params) {
	}

	public javabc.BigInteger getX() {
	}
}
