/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DHKeyGenerationParameters extends org.bouncycastle.crypto.KeyGenerationParameters {

	public DHKeyGenerationParameters(javabc.SecureRandom random, DHParameters params) {
	}

	public DHParameters getParameters() {
	}
}
