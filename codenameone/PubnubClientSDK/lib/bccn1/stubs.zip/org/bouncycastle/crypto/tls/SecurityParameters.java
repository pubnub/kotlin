/**
 * 
 * A lightweight TLS API.
 */
package org.bouncycastle.crypto.tls;


public class SecurityParameters {

	public SecurityParameters() {
	}

	public byte[] getClientRandom() {
	}

	public byte[] getServerRandom() {
	}

	public byte[] getMasterSecret() {
	}
}
