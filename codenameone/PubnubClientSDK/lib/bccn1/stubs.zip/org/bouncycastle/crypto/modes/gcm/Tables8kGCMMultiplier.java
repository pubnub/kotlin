package org.bouncycastle.crypto.modes.gcm;


public class Tables8kGCMMultiplier implements GCMMultiplier {

	public Tables8kGCMMultiplier() {
	}

	public void init(byte[] H) {
	}

	public void multiplyH(byte[] x) {
	}
}
