/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class RC2Parameters implements org.bouncycastle.crypto.CipherParameters {

	public RC2Parameters(byte[] key) {
	}

	public RC2Parameters(byte[] key, int bits) {
	}

	public byte[] getKey() {
	}

	public int getEffectiveKeyBits() {
	}
}
