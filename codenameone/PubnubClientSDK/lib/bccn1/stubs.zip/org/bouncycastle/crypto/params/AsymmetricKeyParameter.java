/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class AsymmetricKeyParameter implements org.bouncycastle.crypto.CipherParameters {

	public AsymmetricKeyParameter(boolean privateKey) {
	}

	public boolean isPrivate() {
	}
}
