/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DHKeyParameters extends AsymmetricKeyParameter {

	protected DHKeyParameters(boolean isPrivate, DHParameters params) {
	}

	public DHParameters getParameters() {
	}

	public boolean equals(Object obj) {
	}

	public int hashCode() {
	}
}
