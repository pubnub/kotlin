/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DSAValidationParameters {

	public DSAValidationParameters(byte[] seed, int counter) {
	}

	public int getCounter() {
	}

	public byte[] getSeed() {
	}

	public int hashCode() {
	}

	public boolean equals(Object o) {
	}
}
