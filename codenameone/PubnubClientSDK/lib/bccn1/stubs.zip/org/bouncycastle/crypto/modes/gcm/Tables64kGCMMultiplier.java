package org.bouncycastle.crypto.modes.gcm;


public class Tables64kGCMMultiplier implements GCMMultiplier {

	public Tables64kGCMMultiplier() {
	}

	public void init(byte[] H) {
	}

	public void multiplyH(byte[] x) {
	}
}
