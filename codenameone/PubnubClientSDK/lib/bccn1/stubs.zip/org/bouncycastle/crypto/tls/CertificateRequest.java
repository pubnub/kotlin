/**
 * 
 * A lightweight TLS API.
 */
package org.bouncycastle.crypto.tls;


public class CertificateRequest {

	public CertificateRequest(short[] certificateTypes, java.util.Vector certificateAuthorities) {
	}

	public short[] getCertificateTypes() {
	}

	/**
	 *  @return Vector of X500Name
	 */
	public java.util.Vector getCertificateAuthorities() {
	}
}
