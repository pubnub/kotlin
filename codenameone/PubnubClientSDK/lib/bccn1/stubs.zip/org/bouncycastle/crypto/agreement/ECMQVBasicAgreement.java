/**
 * 
 * Basic key agreement classes.
 */
package org.bouncycastle.crypto.agreement;


public class ECMQVBasicAgreement implements org.bouncycastle.crypto.BasicAgreement {

	public ECMQVBasicAgreement() {
	}

	public void init(org.bouncycastle.crypto.CipherParameters key) {
	}

	public javabc.BigInteger calculateAgreement(org.bouncycastle.crypto.CipherParameters pubKey) {
	}
}
