/**
 * 
 * A lightweight TLS API.
 */
package org.bouncycastle.crypto.tls;


public class TlsRuntimeException extends RuntimeException {

	public TlsRuntimeException(String message, Throwable e) {
	}

	public TlsRuntimeException(String message) {
	}

	public Throwable getCause() {
	}
}
