/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class ParametersWithSBox implements org.bouncycastle.crypto.CipherParameters {

	public ParametersWithSBox(org.bouncycastle.crypto.CipherParameters parameters, byte[] sBox) {
	}

	public byte[] getSBox() {
	}

	public org.bouncycastle.crypto.CipherParameters getParameters() {
	}
}
