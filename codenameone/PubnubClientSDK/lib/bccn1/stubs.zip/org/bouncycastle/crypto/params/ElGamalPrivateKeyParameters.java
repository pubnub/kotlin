/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class ElGamalPrivateKeyParameters extends ElGamalKeyParameters {

	public ElGamalPrivateKeyParameters(javabc.BigInteger x, ElGamalParameters params) {
	}

	public javabc.BigInteger getX() {
	}

	public boolean equals(Object obj) {
	}

	public int hashCode() {
	}
}
