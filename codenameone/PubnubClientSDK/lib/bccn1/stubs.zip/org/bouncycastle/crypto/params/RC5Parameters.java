/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class RC5Parameters implements org.bouncycastle.crypto.CipherParameters {

	public RC5Parameters(byte[] key, int rounds) {
	}

	public byte[] getKey() {
	}

	public int getRounds() {
	}
}
