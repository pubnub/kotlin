/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DHPrivateKeyParameters extends DHKeyParameters {

	public DHPrivateKeyParameters(javabc.BigInteger x, DHParameters params) {
	}

	public javabc.BigInteger getX() {
	}

	public int hashCode() {
	}

	public boolean equals(Object obj) {
	}
}
