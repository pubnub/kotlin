/**
 * 
 * Classes for creating MACs and HMACs.
 */
package org.bouncycastle.crypto.macs;


/**
 *  implementation of GOST 28147-89 MAC
 */
public class GOST28147Mac implements org.bouncycastle.crypto.Mac {

	public GOST28147Mac() {
	}

	public void init(org.bouncycastle.crypto.CipherParameters params) {
	}

	public String getAlgorithmName() {
	}

	public int getMacSize() {
	}

	public void update(byte in) {
	}

	public void update(byte[] in, int inOff, int len) {
	}

	public int doFinal(byte[] out, int outOff) {
	}

	public void reset() {
	}
}
