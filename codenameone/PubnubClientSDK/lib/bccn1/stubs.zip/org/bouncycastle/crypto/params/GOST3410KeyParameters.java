/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class GOST3410KeyParameters extends AsymmetricKeyParameter {

	public GOST3410KeyParameters(boolean isPrivate, GOST3410Parameters params) {
	}

	public GOST3410Parameters getParameters() {
	}
}
