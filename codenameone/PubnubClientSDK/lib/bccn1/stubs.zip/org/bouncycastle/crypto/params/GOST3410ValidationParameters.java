/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class GOST3410ValidationParameters {

	public GOST3410ValidationParameters(int x0, int c) {
	}

	public GOST3410ValidationParameters(long x0L, long cL) {
	}

	public int getC() {
	}

	public int getX0() {
	}

	public long getCL() {
	}

	public long getX0L() {
	}

	public boolean equals(Object o) {
	}

	public int hashCode() {
	}
}
