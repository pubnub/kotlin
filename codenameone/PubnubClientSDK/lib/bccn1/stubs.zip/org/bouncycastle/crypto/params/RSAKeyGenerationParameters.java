/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class RSAKeyGenerationParameters extends org.bouncycastle.crypto.KeyGenerationParameters {

	public RSAKeyGenerationParameters(javabc.BigInteger publicExponent, javabc.SecureRandom random, int strength, int certainty) {
	}

	public javabc.BigInteger getPublicExponent() {
	}

	public int getCertainty() {
	}
}
