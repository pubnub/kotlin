/**
 * 
 * Lightweight psuedo-random number generators.
 */
package org.bouncycastle.crypto.prng;


public class VMPCRandomGenerator implements RandomGenerator {

	public VMPCRandomGenerator() {
	}

	public void addSeedMaterial(byte[] seed) {
	}

	public void addSeedMaterial(long seed) {
	}

	public void nextBytes(byte[] bytes) {
	}

	public void nextBytes(byte[] bytes, int start, int len) {
	}
}
