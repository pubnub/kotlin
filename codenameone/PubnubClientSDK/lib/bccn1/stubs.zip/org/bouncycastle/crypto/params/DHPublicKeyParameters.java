/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class DHPublicKeyParameters extends DHKeyParameters {

	public DHPublicKeyParameters(javabc.BigInteger y, DHParameters params) {
	}

	public javabc.BigInteger getY() {
	}

	public int hashCode() {
	}

	public boolean equals(Object obj) {
	}
}
