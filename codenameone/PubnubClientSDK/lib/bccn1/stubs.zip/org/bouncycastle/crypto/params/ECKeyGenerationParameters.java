/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class ECKeyGenerationParameters extends org.bouncycastle.crypto.KeyGenerationParameters {

	public ECKeyGenerationParameters(ECDomainParameters domainParams, javabc.SecureRandom random) {
	}

	public ECDomainParameters getDomainParameters() {
	}
}
