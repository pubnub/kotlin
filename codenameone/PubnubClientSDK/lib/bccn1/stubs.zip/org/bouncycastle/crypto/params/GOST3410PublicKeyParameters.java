/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class GOST3410PublicKeyParameters extends GOST3410KeyParameters {

	public GOST3410PublicKeyParameters(javabc.BigInteger y, GOST3410Parameters params) {
	}

	public javabc.BigInteger getY() {
	}
}
