/**
 * 
 * Generators for keys, key pairs and password based encryption algorithms.
 */
package org.bouncycastle.crypto.generators;


public class SCrypt {

	public SCrypt() {
	}

	public static byte[] generate(byte[] P, byte[] S, int N, int r, int p, int dkLen) {
	}
}
