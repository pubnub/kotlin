/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class ElGamalKeyParameters extends AsymmetricKeyParameter {

	protected ElGamalKeyParameters(boolean isPrivate, ElGamalParameters params) {
	}

	public ElGamalParameters getParameters() {
	}

	public int hashCode() {
	}

	public boolean equals(Object obj) {
	}
}
