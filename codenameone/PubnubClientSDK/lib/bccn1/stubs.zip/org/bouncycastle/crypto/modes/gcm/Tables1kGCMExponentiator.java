package org.bouncycastle.crypto.modes.gcm;


public class Tables1kGCMExponentiator implements GCMExponentiator {

	public Tables1kGCMExponentiator() {
	}

	public void init(byte[] x) {
	}

	public void exponentiateX(long pow, byte[] output) {
	}
}
