/**
 * 
 * Classes for creating MACs and HMACs.
 */
package org.bouncycastle.crypto.macs;


public class VMPCMac implements org.bouncycastle.crypto.Mac {

	public VMPCMac() {
	}

	public int doFinal(byte[] out, int outOff) {
	}

	public String getAlgorithmName() {
	}

	public int getMacSize() {
	}

	public void init(org.bouncycastle.crypto.CipherParameters params) {
	}

	public void reset() {
	}

	public void update(byte in) {
	}

	public void update(byte[] in, int inOff, int len) {
	}
}
