/**
 * 
 * Classes for parameter objects for ciphers and generators.
 */
package org.bouncycastle.crypto.params;


public class ElGamalPublicKeyParameters extends ElGamalKeyParameters {

	public ElGamalPublicKeyParameters(javabc.BigInteger y, ElGamalParameters params) {
	}

	public javabc.BigInteger getY() {
	}

	public int hashCode() {
	}

	public boolean equals(Object obj) {
	}
}
